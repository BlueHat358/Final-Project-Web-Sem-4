<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
    <script src="../js/jquery-3.5.1.min.js"></script>
    <script src="../js/style.js"></script>
    <title>Waduk Sermo</title>

    <style>
        .comment-area{
            /*width: 100%;*/
            padding-top: 1rem;
            background-color: #f7bbeb;
        }

        .comment-form-container {
            border: #e0dfdf 2px solid;
            padding: 20px;
            border-radius: 2px;
            width: 100%;
            margin-bottom: 2rem;
        }

        .input-row {
            margin: auto;
            padding-bottom: 20px;
        }

        .input-field {
            width: 100%;
            border-radius: 2px;
            padding: 10px;
            border: #e0dfdf 1px solid;
        }

        .btn-submit {
            padding: 10px 20px;
            background: #333;
            border: #1d1d1d 1px solid;
            color: #f0f0f0;
            font-size: 0.9em;
            width: 100px;
            border-radius: 2px;
            cursor:pointer;
        }

        .btn_kirim{
            text-align: right;
        }

        ul {
            list-style-type: none;
        }

        .comment-row {
            border-bottom: #e0dfdf 1px solid;
            margin-bottom: 15px;
            padding: 15px;
        }

        .outer-comment {
            background: #F0F0F0;
            padding: 20px;
            border: #dedddd 1px solid;
        }

        span.comment-row-label {
            font-style: italic;
        }

        span._admin{
            font-style: italic;
            float: right;
            background-color: #530bcf;
            color: #e6dcf7;
            font-weight: bold;
            padding: 5px;
            border-radius: 5px;
        }

        span.posted-by {
            color: #09F;
        }

        .comment-info {
            font-size: 0.8em;
        }
        .comment-text {
            margin: 10px 0px;
        }
        .btn-reply {
            font-size: 0.8em;
            text-decoration: underline;
            color: #888787;
            cursor:pointer;
        }
        #comment-message {
            margin-left: 20px;
            color: #189a18;
            display: none;
        }
    </style>
</head>

<body>
    
    <div class="header-area" id="navbar">
        <div class="header-top">
            <div class="header-menu-area">
                <nav class="navbar navbar-expand">
                    <div class="header-logo">
                        <a class="navbar-brand" id="text-logo" href="#">Travels</a>
                    </div>
                    <div class="navbar-collapse float-right" id="navbarNavAltMarkup">
                        <div class="navbar-nav ml-auto" id="header-menu">
                            <a class="nav-item nav-link active" href="../">Home</a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>
    
    	<div class="header-bottom" style="background-image: url(../image/waduk-sermo5-crop.jpg);">
    		<div class="content-header">
    			<div class="quote">
                    <h2 class="quote-title">Waduk Sermo</h2>
                    <h4 class="quote-title">Kokap, Kulon Progo</h4>
    			</div>
    		</div>
        </div>
    
    <div class="content-area">
        <div>
            <div class="content">
                <div class="container">
                    <div class="row justify-content-md-center">
                        <div class="col-md-5">
                            <div class="content-container">
                                <div class="content-wrapper">
                                    <div class="content-animate">
                                        <h4>Waduk Sermo</h4>
                                        <p>Waduk Sermo adalah sumber air bersih untuk PDAM dan untuk air irigasi persawahandaerah Wates dan sekitarnya. 
                                            Selain dijadikan sebagai sumber air minum dan irigasi, Waduk Sermo juga menjadi salah satu tempat latihan lomba dayung. 
                                            Waduk Sermo diresmikan oleh Presiden Soeharto pada tanggal 20 November 1996.
                                        </p>
                                        <p>
                                            Lokasi Waduk Sermo ini lumayan strategis, kerena lokasi waduk ini berada diantara dua perbukitan yang dikelilingi oleh banyak pohon cagar alam. 
                                            Waduk Sermo ini memiliki sebuah jalan yang melingkarinya sehingga dapat dengan mudah untuk menikmati pemandangan yang ada 
                                            disekitar waduk ini. Disekitar jalan ini terdapat beberapa tempat persinggahan berbentuk gazebo rumah jamur, dan ada yang berbentuk rumah panggung. 
                                            Disana juga terdapat warung makan, toilet dan villa bagi yang ingin menginap sambil menikmati pemandangan yang tersaji disana. 
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="content-animate1">
                                <h4>Lokasi dan Rute Menuju Waduk Sermo</h4>
                                <p>
                                    Waduk Sermo juga memiliki fasilitas pemancingan. Beberapa wisatawan sangat gemar di Waduk Sermo karena adanya ikan Setan Merah yang 
                                    merupakan ikan predator di Waduk Sermo. Wisatawan juga bisa menyewa perahu wisata untuk berkeliling Waduk Sermo sambil menikmati 
                                    perbukitan Menoreh dan melakukan foto-foto dengan latar keindahan perbukitan Menoreh tersebut.
                                </p>
                                <p>
                                    Lokasi dan alamat Waduk Sermo berada di Desa Hargowilis, Kecamatan Kokap, Kabupaten Kulon Progo. Rute untuk mencapai Waduk Sermo dari Kota Jogja 
                                    kalian tinggal pergi ke arah kota Wates (Alun-alun Wates Kulon Progo) kemudian menuju ke arah Kecamatan Kokap kemudian baru ke arah Waduk Sermo. 
                                    Waduk Sermo ini juga merupakan salah satu jalur yang menuju desa wisata Kalibiru, Gunung Gajah dan Puncak Dipowono. Jadi jika kalian pergi ke Sermo 
                                    tidak ada salahnya untuk pergi mengunjungi tempat wisata tersebut.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="fasilitas-area">
                <div class="container">
                    <div class="row justify-content-sm-center">
                        <div class="col-lg-6 text-center">
                            <div class="fasilitas-title">
                                <h3>Harga Tiket dan Harga Sewa</h3>
                                <hr>
                            </div>
                        </div>
                    </div>
                    <div class="row justify-content-center">
                        <div class="fasilitas1">
                            <div class="col-md-3 d-inline-flex justify-content-between">
                                <div class="fasilitas-wrapper" style="background-image: url(../image/ticket-min.jpg);">
                                    <div class="fasilitas-bg">
                                        <div class="text-fasilitas">
                                            <p>Ticket Anak Rp. 3.000 dan Dewasa Rp. 5.000</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="fasilitas2">
                            <div class="col-md-3 justify-content-between">
                                <div class="fasilitas-wrapper" style="background-image: url(../image/parking-ticket-min.jpg);">
                                    <div class="fasilitas-bg">
                                        <div class="text-fasilitas">
                                            <p>Parkir Motor Rp. 3.000 dan Mobil Rp. 5.000</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="fasilitas3">
                            <div class="col-md-3">
                                <div class="fasilitas-wrapper" style="background-image: url(../image/perahu-min.jpg);">
                                    <div class="fasilitas-bg">
                                        <div class="text-fasilitas">
                                            <p>Sewa Kapal Rp. 30.000</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="image-area">
                <div class="container">
                    <div class="row justify-content-md-center">
                        <div class="col-md-8">
                            <div>
                                <div>
                                    <center>
                                        <div class="col-md-5 text-md-center">
                                            <div class="image-title">
                                                <h3>Foto</h3>
                                                <hr>
                                            </div>
                                        </div>
                                    </center>
                                    <div class="image-show-container">
                                        <div>
                                            <img class="image-show">
                                        </div>
                                    </div>
                                    <div class="image-content-wrapper">
                                        <div class="row justify-content-sm-center">
                                            <div class="col-image">
                                                <div class="image-content">
                                                    <img class="image-source" src="../image/waduk-sermo1-crop.jpeg" alt="" srcset="">
                                                </div>
                                            </div>
                                            <div class="col-image">
                                                <div class="image-content">
                                                    <img class="image-source" src="../image/waduk-sermo2-crop.jpeg" alt="" srcset="">
                                                </div>
                                            </div>
                                            <div class="col-image">
                                                <div class="image-content">
                                                    <img class="image-source" src="../image/waduk-sermo3-crop.jpeg" alt="" srcset="">
                                                </div>
                                            </div>
                                            <div class="col-image">
                                                <div class="image-content">
                                                    <img class="image-source" src="../image/waduk-sermo5-crop.jpg" alt="" srcset="">
                                                </div>
                                            </div>
                                            <div class="col-image">
                                                <div class="image-content">
                                                    <img class="image-source" src="../image/waduk-sermo6-crop.jpg" alt="" srcset="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <center>
        <div class="comment-area">
        <div class="row-comment justify-content-lg-center">
            <div class="col-lg-8">
                <div class="col-lg-6 text-lg-center">
                    <div class="fasilitas-title">
                        <h3>Tinggalkan Jejak</h3>
                        <hr>
                    </div>
                </div>
            </div>
        </div>
        <div class="row-comment justify-content-lg-center">
            <div class="col-lg-6">
                <div class="comment-form-container">
                    <form id="frm-comment">
                        <div class="input-row">
                            <input type="hidden" name="comment_id" id="commentId"
                                placeholder="Name" />
                                <input type="hidden" name="db_name" id="dbName"
                                placeholder="Name" />
                                <input class="input-field"
                                type="text" name="name" id="name" placeholder="Nama" required/>
                        </div>
                        <div class="input-row">
                            <textarea class="input-field" type="text" name="comment"
                                id="comment" placeholder="Masukkan komentar di sini!" rows="5" style="resize: none;" required></textarea>
                        </div>
                        <div class="btn_kirim">
                            <input type="button" class="btn-submit" id="submitButton"
                                value="Kirim"/><div id="comment-message" required>Komentar berhasil ditambahkan!</div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div>
            <div class="row-comment justify-content-lg-center">
                <div class="col-lg-6 text-left">
                    <div id="output"></div>
                        <script>
                            function postReply(commentId) {
                                $('#commentId').val(commentId);
                                $("#name").focus();
                            }

                            $("#submitButton").click(function () {
                                //console.log($('#name').val());
                                if($('#name').val() != "" && $('#comment').val() != ""){
                                    $("#dbName").val("tbl_comment");
                                    // console.log("ada");
                                    $("#comment-message").css('display', 'none');
                                    var str = $("#frm-comment").serialize();
    
                                    $.ajax({
                                        url: "../php/comment-add.php",
                                        data: str,
                                        type: 'post',
                                        success: function (response)
                                        {
                                            var result = eval('(' + response + ')');
                                            if (response)
                                            {
                                                $("#comment-message").css('display', 'inline-block');
                                                $("#name").val("");
                                                $("#comment").val("");
                                                $("#commentId").val("");
                                                listComment();
                                            } else
                                            {
                                                alert("Failed to add comments !");
                                                return false;
                                            }
                                        }
                                    });
                                    
                                    setTimeout(function(){
                                        $("#comment-message").css('display', 'none');
                                    }, 3000);
                                }else{
                                    // console.log("k0song");
                                    alert("Nama dan Komentar tidak boleh kosong");
                                }
                            });
                            
                            $(document).ready(function () {
                                    listComment();
                            });

                            function listComment() {
                                $.post("../php/comment-list.php", {"db_name": "tbl_comment"},
                                        function (data) {
                                                var data = JSON.parse(data);
                                            
                                            var comments = "";
                                            var replies = "";
                                            var item = "";
                                            var parent = -1;
                                            var admin_id = "";
                                            var results = new Array();

                                            var list = $("<ul class='outer-comment'>");
                                            var item = $("<li>").html(comments);

                                            for (var i = 0; (i < data.length); i++)
                                            {
                                                var commentId = data[i]['comment_id'];
                                                parent = data[i]['parent_comment_id'];
                                                admin_id = data[i]['admin_id'];

                                                if (parent == "0")
                                                {
                                                    if(admin_id == "Y85"){
                                                        comments = "<div class='comment-row'>"+
                                                    "<div class='comment-info'><span class='comment-row-label'>from</span> <span class='posted-by'>" + data[i]['comment_sender_name'] + 
                                                    " </span> <span class='comment-row-label'>at</span> <span class='posted-at'>" + data[i]['date'] + "</span><span class='_admin'>Admin</span></div>" + 
                                                    
                                                    "<div class='comment-text'>" + data[i]['comment'] + "</div>"+

                                                    "<div><a class='btn-reply' onClick='postReply(" + commentId + ")'>Reply</a></div>"+
                                                    "</div>";
                                                    }else{
                                                        comments = "<div class='comment-row'>"+
                                                    "<div class='comment-info'><span class='comment-row-label'>from</span> <span class='posted-by'>" + data[i]['comment_sender_name'] + 
                                                    " </span> <span class='comment-row-label'>at</span> <span class='posted-at'>" + data[i]['date'] + "</span></div>" + 
                                                    
                                                    "<div class='comment-text'>" + data[i]['comment'] + "</div>"+

                                                    "<div><a class='btn-reply' onClick='postReply(" + commentId + ")'>Reply</a></div>"+
                                                    "</div>";
                                                    }

                                                    var item = $("<li>").html(comments);
                                                    list.append(item);
                                                    var reply_list = $('<ul>');
                                                    item.append(reply_list);
                                                    listReplies(commentId, data, reply_list);
                                                }
                                            }
                                            $("#output").html(list);
                                        });
                            }

                            function listReplies(commentId, data, list) {
                                for (var i = 0; (i < data.length); i++)
                                {
                                    if (commentId == data[i].parent_comment_id)
                                    {
                                        if(data[i].admin_id == "Y85"){
                                            var comments = "<div class='comment-row'>"+
                                        " <div class='comment-info'><span class='comment-row-label'>from</span> <span class='posted-by'>" + data[i]['comment_sender_name'] + " </span> <span class='comment-row-label'>at</span> <span class='posted-at'>" + data[i]['date'] + "</span><span class='_admin'>Admin</span></div>" + 
                                        "<div class='comment-text'>" + data[i]['comment'] + "</div>"+
                                        "<div><a class='btn-reply' onClick='postReply(" + data[i]['comment_id'] + ")'>Reply</a></div>"+
                                        "</div>";
                                        }else{
                                            var comments = "<div class='comment-row'>"+
                                        " <div class='comment-info'><span class='comment-row-label'>from</span> <span class='posted-by'>" + data[i]['comment_sender_name'] + " </span> <span class='comment-row-label'>at</span> <span class='posted-at'>" + data[i]['date'] + "</span></div>" + 
                                        "<div class='comment-text'>" + data[i]['comment'] + "</div>"+
                                        "<div><a class='btn-reply' onClick='postReply(" + data[i]['comment_id'] + ")'>Reply</a></div>"+
                                        "</div>";
                                        }
                                        var item = $("<li>").html(comments);
                                        var reply_list = $('<ul>');
                                        list.append(item);
                                        item.append(reply_list);
                                        listReplies(data[i].comment_id, data, reply_list);
                                    }
                                }
                            }
                        </script>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </center>
</body>

</html>